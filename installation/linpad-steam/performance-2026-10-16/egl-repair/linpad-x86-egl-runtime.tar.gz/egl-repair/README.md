# Separate Wayland EGL runtime for LinPad

This package adds a separate `/opt/hollow-egl` prefix. It preserves the existing `/opt/hollow-runtime` and Mesa26 Venus overlay. It provides the official Debian trixie GLVND EGL router and a consistent Mesa25 EGL/Gallium/DRI stack, plus the small missing Intel DRM, PCI access and sensors libraries required by the monolithic Gallium binary. Existing matching GBM25, LLVM19 and base libraries are reused. The actual ELF dependency closure resolves across 42 binaries.

Mesa26 Gallium requires GLIBC_2.43, beyond the installed GLIBC_2.41, so that candidate is excluded. This auxiliary EGL stack is for display/window initialization. The game still uses the separate Mesa26 Venus Vulkan ICD. Actual EGL display initialization, GL/ES window configurations, and gameplay require device validation; packaging alone proves none of those.

Run install.sh from this unpacked directory. It verifies base libc/GBM/LLVM/GLdispatch and Venus fingerprints, verifies every payload file/link, refuses conflicting existing files, and writes only under `/opt/hollow-egl`. Capture the ADDED list for exact rollback; removing this new prefix restores the prior state once it is no longer in use.

For the device probe, put `/opt/hollow-egl/usr/lib/x86_64-linux-gnu` before Mesa26 and base library paths; set `__EGL_VENDOR_LIBRARY_FILENAMES=/opt/hollow-egl/usr/share/glvnd/egl_vendor.d/50_mesa.json` and `LIBGL_DRIVERS_PATH=/opt/hollow-egl/usr/lib/x86_64-linux-gnu/dri`. Try `MESA_LOADER_DRIVER_OVERRIDE=zink` with the Mesa26 Venus ICD first. A software EGL fallback can be tested separately if required; neither choice changes the game's explicit Vulkan renderer. The Steam launcher clears these variables, so probe/game wrappers must set them after launcher cleanup.
